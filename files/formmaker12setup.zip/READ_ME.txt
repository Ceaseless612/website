REQUIRED STEP:
Please extract the zip archive.